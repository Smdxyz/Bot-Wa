// commandManager.js
const { getUser, updateUser, addCoin } = require('./userDatabase');
const config = require('./config');
const { readDatabase, writeDatabase } = require('./utils/utils');

async function useCommand(jid, command) {
    let db = await readDatabase();
    const user = await getUser(jid);

    if (!user) {
        return { success: false, message: "User not found" };
    }

    const { ReqEnergy, ReqTier, ReqCoin, CostCoin, Callname } = command;

    // Cek Tier Premium
    const { isActive, tier } = getActivePremium(user);
    if (ReqTier && tier !== ReqTier) {
        return { success: false, message: `Command ini membutuhkan tier premium ${ReqTier}.` };
    }

    // Cek Energi
   if (user.energy < ReqEnergy) {
     return { success: false, message: "Not enough energy!" };
    }

    // Cek Coin
    if (ReqCoin === 'y' && user.coin < CostCoin) {
        return { success: false, message: "Not enough coin!" };
    }

    // Kurangi Energi
    const updatedEnergy = user.energy - ReqEnergy;

    // Kurangi Coin (jika dibutuhkan)
    let updatedCoin = user.coin;
    if (ReqCoin === 'y') {
        updatedCoin -= CostCoin;
    }

    const updatedCommandsUsed = user.commandsUsed + 1;
    await updateUser(jid, { energy: updatedEnergy, coin: updatedCoin, commandsUsed: updatedCommandsUsed });

   db.bot.totalCommandsUsed += 1;
   await writeDatabase(db);

  return { success: true, message: "Command used", user };
}

module.exports = {
  useCommand,
};