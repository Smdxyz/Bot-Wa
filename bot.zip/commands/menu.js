// commands/menu.js
const { formatTime, formatMenu } = require('../utils/formatUtils');
const { getBotStats } = require('../adminManager');
const { readDatabase } = require('../utils/utils');
const { getUser } = require('../userDatabase');
const config = require('../config');
const fs = require('node:fs/promises');
const path = require('path');
const { delay } = require('@whiskeysockets/baileys'); // Import delay using destructuring

module.exports = {
    NamaFitur: 'Menu',
    Callname: 'menu',
    Kategori: 'Info',
    SubKategori: 'Bot',
    ReqEnergy: 0,
    ReqTier: null,
    ReqCoin: 'n',
    CostCoin: 0,
    Deskripsi: 'Menampilkan menu dan informasi bot dengan tampilan yang lebih menarik.',
    execute: async function (sock, msg, commands) {
        const jid = msg.key.remoteJid;

        // Tampilkan pesan loading
        await sock.sendMessage(jid, { text: "Memuat menu... ⏳" });
        await delay(2000); // Delay untuk efek animasi

        const startTime = process.hrtime();
        const botStats = await getBotStats();
        const endTime = process.hrtime(startTime);
        const runtimeSeconds = endTime[0] + endTime[1] / 1e9;
        const runtime = formatTime(runtimeSeconds);

        const db = await readDatabase();
        const user = await getUser(jid);
        const popularCommands = Object.values(db.users).reduce((acc, user) => {
            const commandsUsed = user.commandsUsed || 0;
            if (commandsUsed > 0) {
                // Asumsikan command yang paling sering digunakan adalah command pertama
                const commandName = commandsUsed > 0 ? Object.keys(commands)[0] : '!example';
                const existingCommand = acc.find(cmd => cmd.name === commandName);
                if (existingCommand) {
                    existingCommand.count += commandsUsed;
                } else {
                    acc.push({ name: commandName, count: commandsUsed });
                }
            }

            return acc;
        }, []);

        const watermark = '© Your Bot Name 2024';
        const menuText = formatMenu(config.botName, runtime, botStats, popularCommands, commands, watermark);
        const userText = `\n*Data Pengguna:*\n` +
            `  - Coin: ${user.coin}\n` +
            `  - Energy: ${user.energy}\n` +
            `  - Level: ${user.level}\n` +
            `  - Premium Tier: ${user.premiumTier}\n` +
            `  - Commands Used: ${user.commandsUsed}\n`;

        const imageUrl = 'https://example.com/bot_image.jpg'; // Ganti dengan URL gambar Anda
        const hasButtonSupport = false; // Ubah menjadi true jika ada fitur yang mendukung tombol

        const messageOptions = {
            text: menuText + userText,
            footer: watermark,
            headerType: 1,
            contextInfo: {
                externalAdReply: {
                    title: config.botName + " Menu",
                    body: "Informasi dan daftar perintah bot.",
                    thumbnailUrl: imageUrl,
                    sourceUrl: "https://github.com/Smdxyz",
                    showAdAttribution: true,
                },
            },
        };

        if (hasButtonSupport) {
            const buttons = [
                { buttonId: '!help', buttonText: { displayText: 'Bantuan' }, type: 1 },
                { buttonId: '!profile', buttonText: { displayText: 'Profil' }, type: 1 },
            ];
            messageOptions.buttons = buttons;
            messageOptions.headerType = 4; // Ubah headerType jika menggunakan tombol
        }

        // Kirim menu
        await sock.sendMessage(jid, messageOptions);
    },
};