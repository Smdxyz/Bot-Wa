// commands/ping.js
module.exports = {
    NamaFitur: 'Ping',
    Callname: 'ping',
    Kategori: 'Umum',
    SubKategori: 'Informasi',
    ReqEnergy: 1,
    ReqTier: null,
    ReqCoin: 'n',
    CostCoin: 0,
    Deskripsi: 'Menampilkan waktu respons bot.',
    execute: async function (sock, msg, commands, { isActive, tier, multiplier, mediaType }) {
        const jid = msg.key.remoteJid;
        const now = Date.now();
        const sentMsg = await sock.sendMessage(jid, { text: 'Pong!' });
        const latency = Date.now() - now;
        await sock.sendMessage(jid, { text: `Latensi: ${latency}ms` });
    }
}