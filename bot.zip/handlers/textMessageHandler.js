// handlers/textMessageHandler.js
const { format } = require('util');
const { getUser } = require('../userDatabase');

module.exports = async (sock, msg, commands, { isActive, tier, multiplier }) => {
    const jid = msg.key.remoteJid;
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || "";
    const user = await getUser(jid);

    if (text.startsWith('!')) {
        const commandName = text.slice(1).split(' ')[0].toLowerCase();
        const command = commands.get(commandName);
        if (command) {
            try {
                // Logika useCommand sudah dipindahkan ke index.js
                await command.execute(sock, msg, commands, { isActive, tier, multiplier });
                return;
            } catch (err) {
                console.error("Command execute error:", err);
                await sock.sendMessage(msg.key.remoteJid, { text: "Terjadi kesalahan ketika menjalankan perintah" });
                return;
            }
        } else {
            await sock.sendMessage(msg.key.remoteJid, { text: `Command ${commandName} tidak ditemukan!` });
            return;
        }
    }
};