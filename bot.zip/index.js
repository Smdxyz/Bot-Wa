// handlers/captionMessageHandler.js
const { getUser } = require('../userDatabase');

module.exports = async (sock, msg, commands, { useCommand, isActive, tier, multiplier }) => {
    let caption = "";
    let mediaType = null;

    if (msg.message.imageMessage) {
        caption = msg.message.imageMessage?.caption || "";
        mediaType = 'image';
    } else if (msg.message.videoMessage) {
        caption = msg.message.videoMessage?.caption || "";
        mediaType = 'video';
    }

    console.log('Pesan dengan Caption:', caption);

    if (caption.startsWith('!')) {
        const commandName = caption.slice(1).split(' ')[0].toLowerCase();
        const command = commands.get(commandName);
        if (command) {
            try {
                // Tidak perlu memanggil useCommand di sini, sudah dipanggil di index.js
                // const { success, message } = await useCommand(msg.key.remoteJid);
                // if (!success) {
                //     await sock.sendMessage(msg.key.remoteJid, { text: message });
                //      return;
                // }
                // Mengirim media message ke command
                await command.execute(sock, msg, commands, { mediaType, isActive, tier, multiplier });
                return;
            } catch (err) {
                console.error("Command execute error:", err);
                await sock.sendMessage(msg.key.remoteJid, { text: "Terjadi kesalahan ketika menjalankan perintah" });
                return;
            }
        } else {
            await sock.sendMessage(msg.key.remoteJid, { text: `Command ${commandName} tidak ditemukan!` });
             return;
        }
    }
    // Remove the media processing logic from here
    // no download / save media if not command
    console.log('Pesan tanpa Command');

   await sock.sendMessage(msg.key.remoteJid, {
        text: `Pesan dengan Caption Diterima: ${caption}. Tidak ada perintah untuk dijalankan.`,
    });
     return;
};