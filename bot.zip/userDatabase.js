// userDatabase.js
const { readDatabase, writeDatabase } = require('./utils/utils');
const moment = require('moment-timezone');

async function getUser(jid) {
    const db = await readDatabase();
    return db.users[jid] || null;
}

async function createUser(jid) {
    const db = await readDatabase();
    const userId = jid;
    db.users[userId] = {
        coin: 0,
        energy: 100,
        level: 0,
        premiumTier: "Super Kere",
        premiumEndTime: null,
        commandsUsed: 0,
        score: 0,
        lastMessageTime: null,
        achievements: [], // Tambahkan array achievements
        messagesSent: 0, // Tambahkan field messagesSent
    };
    db.bot.totalUsers += 1;

    await writeDatabase(db);
}

async function updateUser(jid, update) {
    const db = await readDatabase();
    if (db.users[jid]) {
        db.users[jid] = { ...db.users[jid], ...update };
        await writeDatabase(db);
    }
}

async function getAllUsers() {
    const db = await readDatabase();
    return db.users;
}
async function addCoin(jid, amount) {
    const db = await readDatabase();
    if (db.users[jid]) {
        db.users[jid].coin += amount;
        await writeDatabase(db);
        return true;
    }
    return false;
}

async function addEnergy(jid, amount) {
    const db = await readDatabase();
    if (db.users[jid]) {
        db.users[jid].energy += amount;
        await writeDatabase(db);
        return true;
    }
    return false;
}

async function addScore(jid, score) {
    const db = await readDatabase();
    if (db.users[jid]) {
        const user = db.users[jid];
        user.score += score;
        user.lastMessageTime = moment.tz('Asia/Jakarta').toISOString();

        if (user.score >= 50 && user.level < 10) {
            user.score = 0;
            user.level += 1;
            user.coin += 100;
            user.energy += 50;
            console.log(`[userDatabase.js] User ${jid} naik level menjadi ${user.level}!`);
        }

        await writeDatabase(db);
        return true;
    }
    return false;
}

async function addAchievement(jid, achievementId) {
    const db = await readDatabase();
    if (db.users[jid]) {
        const user = db.users[jid];
        if (!user.achievements.includes(achievementId)) {
            user.achievements.push(achievementId);
            await writeDatabase(db);
            return true;
        }
    }
    return false;
}

module.exports = {
    getUser,
    createUser,
    updateUser,
    getAllUsers,
    addCoin,
    addEnergy,
    addScore,
    addAchievement,
};