// utils/formatUtils.js

function formatTime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    seconds %= (3600 * 24);
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);

    let timeString = "";
    if (days > 0) timeString += `${days} hari, `;
    if (hours > 0) timeString += `${hours} jam, `;
    if (minutes > 0) timeString += `${minutes} menit, `;
    timeString += `${secs} detik`;
    return timeString;
}
function formatMenu(botName, runtime, botStats, popularCommands, commands, watermark){
    let menu = `*${botName}*\n\n`;
    menu += `*Runtime:* ${runtime}\n`;
    menu += `*Total Pengguna:* ${botStats.totalUsers}\n`
    menu += `*Total Command Digunakan:* ${botStats.totalCommandsUsed}\n\n`;
    menu += `*Command Terpopuler:*\n`;
    if (popularCommands.length > 0) {
        popularCommands.forEach((cmd, i) => {
            menu += `${i+1}. ${cmd.name} (digunakan ${cmd.count} kali)\n`;
        });
        }else{
            menu += "Belum ada Command yang digunakan\n"
        }
        menu += `\n*List Command:*\n`;
       const categorizedCommands = Array.from(commands.values()).reduce((acc, command) => {
            const { category = "Lainnya", subCategory = "Umum", name, description } = command;
            if (!acc[category]) {
                acc[category] = {};
            }
             if (!acc[category][subCategory]) {
                acc[category][subCategory] = [];
            }
            acc[category][subCategory].push({ name, description});
            return acc;
        }, {});
        for (const category in categorizedCommands) {
            menu += `\n*${category}*:\n`;
             for(const subCategory in categorizedCommands[category]){
                menu += `  *${subCategory}*:\n`;
                categorizedCommands[category][subCategory].forEach(cmd => {
                    menu += `    - ${cmd.name} : ${cmd.description || "Tidak ada deskripsi"}\n`;
                });
           }
        }
        menu += `\n${watermark}`
        return menu
}

module.exports = {
    formatTime,
    formatMenu
};