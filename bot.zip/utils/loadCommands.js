// utils/loadCommands.js
const fs = require('node:fs/promises');
const path = require('path');

async function loadCommands() {
    const commands = new Map();
    const commandsPath = path.join(__dirname, '..', 'commands');

    try {
        const commandFiles = await fs.readdir(commandsPath);
        for (const file of commandFiles) {
            if (file.endsWith('.js')) {
                const filePath = path.join(commandsPath, file);
                const command = require(filePath);
                if (command.name && command.execute) {
                  const { name, description, category, subCategory, execute } = command
                   commands.set(name.toLowerCase(), {name, description, category, subCategory, execute, ...command});
                   console.log(`[loadCommands] Command loaded: ${command.name}`);
                } else {
                    console.log(`[loadCommands] Skipping invalid command file: ${file}`);
                }
            }
        }
    } catch (error) {
        console.error('[loadCommands] Error loading commands:', error);
    }

    return commands;
}

module.exports = loadCommands;