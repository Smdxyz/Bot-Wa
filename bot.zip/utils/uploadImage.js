const axios = require('axios');
const FormData = require('form-data');

const uploadImage = async (buffer) => {
    const formData = new FormData();
    formData.append('image', buffer, { filename: 'image.jpg' });

    try {
        const response = await axios.post(
            'https://api.imgbb.com/1/upload?key=1c5908ad14f2220107a77efcbf0d7043',
            formData,
            {
                headers: {
                    ...formData.getHeaders(),
                },
            }
        );

        if (response.data && response.data.success) {
            return response.data.data.url;
        } else {
            console.error('Image upload failed:', response.data);
            throw new Error('Image upload failed');
        }
    } catch (error) {
        console.error('Error uploading image:', error);
        throw new Error('Error uploading image');
    }
};

module.exports = uploadImage;