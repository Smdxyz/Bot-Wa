// utils/utils.js
const fs = require('fs').promises;
const path = require('path');

const dbPath = path.join(__dirname, 'database.json');

async function readDatabase() {
    try {
        const data = await fs.readFile(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        // Jika file tidak ada, buat database baru
        if (error.code === 'ENOENT') {
            console.log('Database file not found, creating a new one.');
            const newDb = { users: {}, bot: { totalUsers: 0 } };
            await writeDatabase(newDb);
            return newDb;
        }
        console.error('Error reading database:', error);
        throw error;
    }
}

async function writeDatabase(data) {
    try {
        await fs.writeFile(dbPath, JSON.stringify(data, null, 2), 'utf8');
    } catch (error) {
        console.error('Error writing database:', error);
        throw error;
    }
}

function generateRandomId(length = 8) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

module.exports = {
    readDatabase,
    writeDatabase,
    generateRandomId
};